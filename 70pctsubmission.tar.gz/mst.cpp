#include "tspsolve.h"
#include<string>

string itos(int i){ // i >= 0 
    if(i==0)
        return "0";

    string s;

    while(i != 0){
        s.push_back( (char) ((i % 10) + 48) );
        i = i/10;
    }

    int size = s.size();

    string toret(size, '0');
    for(int j = 0; j != size; j++){
        toret[j] = s[size - j - 1];
    }

    return toret;
}

int TSPsolver::makeMST(){
    deque<int> n;

    for (int i=0; i < numNodes; i++)
        n.push_back(i);

    return MST_help(true, n);
}

int TSPsolver::MST_help(bool toPrint, const deque<int>& nl){
    if(nl.empty())
        return 0;

    deque<int> nodes_left = nl; 

    typedef deque<int>::iterator deqIt;

    if(distVect.empty())
        distVect.assign(numNodes, -1); 
    if(parentVect.empty())
        parentVect.assign(numNodes, -1);

    int start = nodes_left.front();
    nodes_left.pop_front();

    int weightToRet = 0;
    int toAdd; //index of next node to add to MST
    deqIt toDelete;
    int oldToAdd;
    int rent; //may make things slow...
    int newDist;

    for(deqIt i=nodes_left.begin(); i != nodes_left.end(); i++){
        distVect[*i] = norm(PtsToVisit[*i], PtsToVisit[start]);
        parentVect[*i] = start;
        toAdd = *i;
        toDelete = i;
    }

    string output;

    while(!nodes_left.empty()){
        for(deqIt i=nodes_left.begin(); i != nodes_left.end(); i++){
            //find node with least distance
            if(distVect[toAdd] > distVect[*i]){
                toAdd = *i;
                toDelete = i; 
            }
        }
        //add that node: add nearest node and node to string,
        nodes_left.erase(toDelete);
        weightToRet += distVect[toAdd];
        rent = parentVect[toAdd]; 
        if(toPrint){
            (rent < toAdd ?
                    output += itos(rent) + " " + itos(toAdd):
                    output += itos(toAdd) + " " + itos(rent));
            output.push_back('\n');
        }
        //change distances
        
        oldToAdd = toAdd;
        
        for(deqIt i=nodes_left.begin(); i != nodes_left.end(); i++){
                toAdd = *i; //need to do this for the for loop above
                toDelete = i; //and this
                newDist = norm(PtsToVisit[*i], PtsToVisit[oldToAdd]);
                if(newDist < distVect[*i]){
                    distVect[*i]= newDist;
                    parentVect[*i] = oldToAdd;
                }
        }
    }

    if(toPrint)
        cout << weightToRet << '\n' << output;
    
    return weightToRet;
}

