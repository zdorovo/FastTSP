#include "tspsolve.h"

int vectDistSum(const vector<int>&);

void TSPsolver::solveTSP_fast(){
    deque<int> nodesLeft;
    for(int i=1; i < numNodes; i++)
        nodesLeft.push_back(i);

    typedef deque<int>::iterator deqIt;

    int closest;
    int minDist;
    int newDist;
    deqIt toDelete, it;

    tspSolution.push_back(0);
    solWeight = 0;

    while(!nodesLeft.empty()){
        it = nodesLeft.begin();
        minDist = norm(PtsToVisit[*it], PtsToVisit[tspSolution.back()]);
        closest = *it;
        toDelete = it;

        for(it++; it != nodesLeft.end(); it++){
           newDist = norm(PtsToVisit[*it], PtsToVisit[tspSolution.back()]);
           if(newDist < minDist){
               minDist = newDist;
               closest = *it;
               toDelete = it;
           }
        }

        tspSolution.push_back(closest);
        nodesLeft.erase(toDelete);
        solWeight += minDist;
    }

    solWeight += norm(PtsToVisit[tspSolution.back()], PtsToVisit[0]);

    return;
}

int TSPsolver::vectDistSum(const vector<int>& v){
    return 0;
}
