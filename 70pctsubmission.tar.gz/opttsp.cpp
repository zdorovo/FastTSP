#include "tspsolve.h"

void TSPsolver::solveTSP_opt(){
    deque<int> d, n;
    d.push_back(0);
    for(int i=1; i<numNodes; i++)
        n.push_back(i);
    solveTSP_opt_help(d, 0, n);
}

void TSPsolver::solveTSP_opt_help(deque<int>& cakeWalk, int curWeight, deque<int>& nodes_left){
    typedef deque<int>::iterator deqIt;

    int val;
    int rent;

    if(promising(curWeight, nodes_left))
        if(nodes_left.empty()){
            solWeight = curWeight;
            solWeight += norm(PtsToVisit[cakeWalk.back()], PtsToVisit[0]);
            tspSolution = cakeWalk;
        }
        else
            for(deqIt i = nodes_left.begin(); i != nodes_left.end(); i++){
                val = *i;
                i = nodes_left.erase(i);

                rent = cakeWalk.back();
                cakeWalk.push_back(val);

                solveTSP_opt_help(cakeWalk,
                        curWeight + norm(PtsToVisit[rent], PtsToVisit[val]),
                        nodes_left);

                cakeWalk.pop_back();
                i =  nodes_left.insert(i, val);
            }
        
    
       
    return;
}

bool TSPsolver::promising(int curWeight, const deque<int>& nodes_left){
    if(curWeight + MST_help(false, nodes_left) < solWeight)
        return true;
    return false;
}
