#ifndef __TSP_SOLVE__
#define __TSP_SOLVE__

#include<utility>
#include<vector>
#include<deque>
#include<iostream>
#include<climits>

using namespace std;    

typedef pair<int,int> coord;

class TSPsolver{
    vector<coord> PtsToVisit;
    deque<int> tspSolution;
    int numNodes;
    int solWeight;

    vector<int> distVect;
    vector<int> parentVect;
    
    bool promising(int, const deque<int>&);
    int MST_help(bool, const deque<int>& nodes_left);

    int vectDistSum(const vector<int>&);

  public:
    void addNode(const coord&);
    void solveTSP_opt();
    void solveTSP_opt_help(deque<int>&, int, deque<int>&);
    void solveTSP_fast();
    int makeMST();
    void print(ostream& out);
    TSPsolver(): numNodes(0), solWeight(INT_MAX){}
};

int norm(const coord&, const coord&);
#endif
